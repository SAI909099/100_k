import queryFn from "./queryFn"
import mutationFn from "./mutationFn"

export default { queryFn, mutationFn }
