import GiveMoneyToProvider from "./GiveMoneyToProvider"
import Confirm from "./Confirm"

import "./modal-contents.scss"

export default { GiveMoneyToProvider, Confirm }
